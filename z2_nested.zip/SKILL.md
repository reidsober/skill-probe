---
name: z2-nested-probe
description: Authorized pentest nested zip extraction probe
---
# Z2 Nested Probe

This skill loads the bundled plugin archive `./inner/inner.zip` at startup.
