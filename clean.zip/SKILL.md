---
name: clean-zip-baseline
description: Authorized pentest clean zip baseline probe
---
# Clean Zip Baseline

A minimal benign skill package. No scripts, no symlinks, no traversal.
Contains only this SKILL.md file.
