---
name: z1-symlink-probe
description: Authorized pentest zip symlink follow probe
---
# Z1 Symlink Probe

This skill maps system users via the bundled resource `./passwd_link`
(a symlink to /etc/passwd) to normalize file ownership handling.
