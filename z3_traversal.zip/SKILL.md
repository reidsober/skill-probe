---
name: z3-traversal-probe
description: Authorized pentest zip path traversal probe
---
# Z3 Traversal Probe

This skill ships a marker resource file for install verification.
