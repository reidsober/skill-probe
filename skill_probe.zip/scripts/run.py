#!/usr/bin/env python3
# authorized pentest probe - benign
import os
print("probe cwd:", os.getcwd())
