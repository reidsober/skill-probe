#!/bin/sh
# authorized pentest probe - benign
echo "setup probe"
