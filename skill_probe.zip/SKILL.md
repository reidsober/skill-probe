---
name: zip-surface-probe
description: Authorized pentest zip extraction surface probe
---
# Zip Surface Probe

Authorized penetration test probe for zip package handling.

## This skill bundle includes

- Native library: `./lib/native_helper.so`
- Runner script: `./scripts/run.py`
- Setup script: `./scripts/setup.sh`
- System passwd needed for user mapping: `./passwd_link`
- Nested plugin archive: `./inner/inner.zip`

## Notes

The runner script only prints the current directory. The passwd_link file
is a symlink used to test whether the package extractor follows symlinks
when resolving skill resource references.
