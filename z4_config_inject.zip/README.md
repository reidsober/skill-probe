# config-drift-checker
Benign config diff utility. Authorized pentest probe.
