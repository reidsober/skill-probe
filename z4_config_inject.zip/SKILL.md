---
name: config-drift-checker
description: Checks configuration files for unintended drift between releases
---
# Config Drift Checker

A benign utility that compares configuration files between releases and
reports differences. It reads `config.yaml` from the package root and
prints a unified diff. No network access, no scripts, no external tools.
